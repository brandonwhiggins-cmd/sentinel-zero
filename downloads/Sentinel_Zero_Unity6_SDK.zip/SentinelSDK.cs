// =============================================================================
// Project: Sentinel Zero / Open Anti-Cheat Standard (OACS)
// File: SentinelSDK.cs
// Engine: Unity 6 (6000.x) / Netcode for GameObjects & Mirror / FishNet
// Author: Brandon Higgins ("SknotRockit")
// Description: Turnkey C# Unity 6 Dedicated Server SDK for Spatial Fog-of-War
//              and Ephemeral Mid-Match Nonce Attestation.
// =============================================================================

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

namespace SentinelZero.SDK
{
    public enum SentinelAttestationVerdict
    {
        CleanVerified,
        HardwareViolation_DMA,
        MacroScript_Cronus,
        OverlayHook_ImGui,
        Hypervisor_VMExit_Detected,
        InvalidSignature
    }

    [System.Serializable]
    public struct SpatialBox2D
    {
        public float minX;
        public float minY;
        public float maxX;
        public float maxY;

        public SpatialBox2D(Vector2 min, Vector2 max)
        {
            minX = Mathf.Min(min.x, max.x);
            minY = Mathf.Min(min.y, max.y);
            maxX = Mathf.Max(min.x, max.x);
            maxY = Mathf.Max(min.y, max.y);
        }
    }

    /// <summary>
    /// Sentinel Zero Dedicated Server Authority for Unity 6
    /// </summary>
    public class SentinelServerSubsystem : MonoBehaviour
    {
        public static SentinelServerSubsystem Instance { get; private set; }

        private List<SpatialBox2D> cachedOccluders = new List<SpatialBox2D>(512);
        private Dictionary<uint, NonceRecord> activeSessions = new Dictionary<uint, NonceRecord>();

        private struct NonceRecord
        {
            public ulong challengeNonce;
            public double issuedTimestamp;
            public int failureCount;
        }

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);
                Debug.Log("[Sentinel Zero] Initialized Unity 6 Server-Side Fog-of-War & In-Band UDP Security Engine.");
            }
            else
            {
                Destroy(gameObject);
            }
        }

        /// <summary>
        /// Register static map occluder boundary (Buildings, Walls, Terrain Boulders)
        /// </summary>
        public void RegisterOccluderWall(Vector2 minBounds, Vector2 maxBounds)
        {
            cachedOccluders.Add(new SpatialBox2D(minBounds, maxBounds));
        }

        /// <summary>
        /// Unity 6 Network Transform Sanitizer & Relevancy Filter (Netcode for GameObjects / FishNet / Mirror)
        /// Returns TRUE if target enemy is occluded from this specific viewer connection (drops coordinate payload).
        /// </summary>
        public bool IsOccludedFromConnection(Vector3 viewerPos, Vector3 viewerVel, Vector3 enemyPos, Vector3 enemyVel, float viewerRttMs)
        {
            float rttSec = viewerRttMs > 0 ? viewerRttMs / 1000.0f : 0.045f;
            float relativeSpeed = (new Vector2(viewerVel.x, viewerVel.z).magnitude + new Vector2(enemyVel.x, enemyVel.z).magnitude);
            float predictivePeelDist = Mathf.Clamp(relativeSpeed * rttSec, 2.0f, 15.0f); // In meters

            float deltaX = enemyPos.x - viewerPos.x;
            float deltaZ = enemyPos.z - viewerPos.z;
            float distSq = (deltaX * deltaX) + (deltaZ * deltaZ);
            float dist = Mathf.Sqrt(distSq);

            // Close combat / audio envelope: Not occluded
            if (dist <= predictivePeelDist)
            {
                return false;
            }

            float dirX = deltaX / dist;
            float dirZ = deltaZ / dist;
            float invDirX = Mathf.Abs(dirX) > 1e-6f ? (1.0f / dirX) : 1e6f;
            float invDirZ = Mathf.Abs(dirZ) > 1e-6f ? (1.0f / dirZ) : 1e6f;

            // Fast Slab 2D Ray-AABB test
            for (int i = 0; i < cachedOccluders.Count; i++)
            {
                SpatialBox2D box = cachedOccluders[i];
                float t1 = (box.minX - viewerPos.x) * invDirX;
                float t2 = (box.maxX - viewerPos.x) * invDirX;
                float t3 = (box.minY - viewerPos.z) * invDirZ;
                float t4 = (box.maxY - viewerPos.z) * invDirZ;

                float tmin = Mathf.Max(Mathf.Min(t1, t2), Mathf.Min(t3, t4));
                float tmax = Mathf.Min(Mathf.Max(t1, t2), Mathf.Max(t3, t4));

                if (tmax >= 0.0f && tmin <= tmax && tmin < dist)
                {
                    // Occluded: Strip coordinate from packet serialization buffer!
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Issue 64-bit cryptographic challenge nonce for mid-match verification
        /// </summary>
        public ulong IssueClientHeartbeatChallenge(uint playerSessionId)
        {
            byte[] bytes = new byte[8];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(bytes);
            }
            ulong nonce = BitConverter.ToUInt64(bytes, 0);

            activeSessions[playerSessionId] = new NonceRecord
            {
                challengeNonce = nonce,
                issuedTimestamp = Time.realtimeSinceStartupAsDouble,
                failureCount = 0
            };

            return nonce;
        }

        /// <summary>
        /// Verify in-band client heartbeat nonce response (via Unity ServerRpc)
        /// </summary>
        public bool VerifyMidMatchHeartbeatNonce(uint playerSessionId, ulong receivedNonce, string clientHmacSignature)
        {
            if (!activeSessions.TryGetValue(playerSessionId, out NonceRecord record))
            {
                return false;
            }

            double elapsed = Time.realtimeSinceStartupAsDouble - record.issuedTimestamp;
            if (elapsed > 2.5)
            {
                return false;
            }

            if (receivedNonce != record.challengeNonce)
            {
                return false;
            }

            string expectedPayload = $"{receivedNonce}:{playerSessionId}";
            using (MD5 md5 = MD5.Create())
            {
                byte[] hash = md5.ComputeHash(Encoding.UTF8.GetBytes(expectedPayload));
                string computedSig = BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
                return computedSig.Equals(clientHmacSignature, StringComparison.OrdinalIgnoreCase);
            }
        }
    }
}
