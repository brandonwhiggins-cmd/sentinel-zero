# 🏖️ SENTINEL ZERO (OACS) — Unity 6 Server Integration Guide
**Turnkey Security & Fog-of-War Middleware for SAND (Hologryph / tinyBuild)**

---

## ⚡ Quick Start: 3-Minute Integration in Unity 6

Sentinel Zero for **Unity 6** provides a drop-in C# Server Subsystem (`SentinelSDK.cs`) that integrates directly with **Netcode for GameObjects, FishNet, or Mirror**.

### 1. Drop `SentinelSDK.cs` into your Server Scripts Folder
Attach `SentinelServerSubsystem` to a persistent Server GameManager object in your dedicated server scene.

### 2. Register Trampler / Building Occluder Walls
```csharp
// In your map loader / level generator:
SentinelServerSubsystem.Instance.RegisterOccluderWall(
    new Vector2(wallMinX, wallMinZ), 
    new Vector2(wallMaxX, wallMaxZ)
);
```

### 3. Connection Relevancy Filter (Netcode for GameObjects)
In your `NetworkTransform` or custom `NetworkVisibilityCondition`:
```csharp
public override bool CheckVisibility(NetworkClient client)
{
    Vector3 viewerPos = client.PlayerObject.transform.position;
    Vector3 viewerVel = client.PlayerObject.GetComponent<Rigidbody>().velocity;
    float clientRtt = client.GetPing();

    bool isOccluded = SentinelServerSubsystem.Instance.IsOccludedFromConnection(
        viewerPos, viewerVel, 
        transform.position, GetComponent<Rigidbody>().velocity, 
        clientRtt
    );

    // If occluded behind structures, drop coordinate packet for this client!
    return !isOccluded;
}
```

### 4. Benefits for SAND Playtests:
*   **Blinds 2nd-PC DMA Radars**: Hidden players and rival Tramplers have zero coordinate allocations in client RAM.
*   **0% Ongoing Client CPU Loss**: Raycasting happens on the dedicated server in under 0.5ms.
*   **Stateless Pre-Launch Attestation**: Players don't need 24/7 background kernel spyware running on their PCs.
