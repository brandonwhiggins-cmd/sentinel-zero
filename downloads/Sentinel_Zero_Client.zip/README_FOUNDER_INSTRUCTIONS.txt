========================================================================
🛡️ SENTINEL ZERO COMPETITIVE DESKTOP CLIENT (EARLY ACCESS V0.1)
========================================================================
Built for: Swag (@wubstract) & Brandon (@SknotRockIt)
Founder Privileges: Lifetime Free VIP Pass (.00/mo)

QUICK START INSTRUCTIONS:
1. Double-click 'Sentinel Zero Client.exe' to launch the standalone client.
2. The client will automatically verify hardware TPM 2.0.
3. Open 'Game Passport' in the top bar to link your Steam (Wubstract) 
   and Xbox (H1N2 SwagFlu) gamertags.
4. Try out the 1-Click Steam Game Launcher in Counter-Strike 2!

Note: Because this is a custom-compiled private alpha build, Windows SmartScreen
may ask 'More info' -> 'Run anyway' on first launch.
========================================================================
